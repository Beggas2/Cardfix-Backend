# Backend do Aplicativo de Concursos

Backend completo para aplicativo de concursos com geração de cards por IA, desenvolvido em Node.js com Express, TypeScript e PostgreSQL.

## 🚀 Tecnologias Utilizadas

- **Node.js** + **Express** - Framework web
- **TypeScript** - Tipagem estática
- **PostgreSQL** - Banco de dados relacional
- **Prisma** - ORM para banco de dados
- **OpenAI API** - Geração de cards por IA
- **JWT** - Autenticação
- **Multer** - Upload de arquivos
- **Bcrypt** - Hash de senhas

## 📋 Funcionalidades

### ✅ Autenticação e Usuários
- Registro e login de usuários
- Autenticação JWT
- Perfis de usuário
- Sistema de assinaturas (free/premium)

### ✅ Gerenciamento de Concursos
- CRUD completo de concursos
- Upload e processamento de editais (PDF)
- Associação de tópicos aos concursos
- Datas de prova e metas de estudo

### ✅ Sistema de Tópicos e Subtópicos
- Hierarquia: Concursos → Tópicos → Subtópicos → Cards
- CRUD de tópicos e subtópicos
- Organização estruturada do conteúdo

### ✅ Geração de Cards por IA
- Integração com OpenAI GPT-4
- Geração automática baseada em editais
- Prompts especializados para concursos públicos
- Limitações por tier de assinatura

### ✅ Sistema de Estudo (Spaced Repetition)
- Algoritmo SM-2 para repetição espaçada
- Sessões de estudo personalizadas
- Tracking de progresso e performance
- Estatísticas detalhadas por tópico/subtópico

### ✅ Armazenamento e Recuperação
- Cards manuais e gerados por IA
- Histórico de revisões
- Métricas de acerto/erro
- Status de aprendizado

## 🛠️ Instalação e Configuração

### Pré-requisitos
- Node.js 18+
- PostgreSQL 12+
- Conta OpenAI (para geração de cards)

### 1. Instalar dependências
```bash
npm install
```

### 2. Configurar variáveis de ambiente
Copie o arquivo `.env` e configure as variáveis:

```env
# Database
DATABASE_URL="postgresql://username:password@localhost:5432/concurso_db?schema=public"

# JWT
JWT_SECRET="your-super-secret-jwt-key-change-this-in-production"
JWT_EXPIRES_IN="7d"

# OpenAI
OPENAI_API_KEY="your-openai-api-key"

# Server
PORT=3001
NODE_ENV="development"

# File Upload
MAX_FILE_SIZE=10485760  # 10MB
UPLOAD_DIR="uploads"

# CORS
CORS_ORIGIN="http://localhost:5173"
```

### 3. Configurar banco de dados
```bash
# Gerar cliente Prisma
npm run prisma:generate

# Executar migrations
npm run prisma:migrate

# (Opcional) Abrir Prisma Studio
npm run prisma:studio
```

### 4. Executar o servidor
```bash
# Desenvolvimento
npm run dev

# Produção
npm run build
npm start
```

## 📚 API Endpoints

### Autenticação
- `POST /api/auth/register` - Registrar usuário
- `POST /api/auth/login` - Login
- `GET /api/auth/profile` - Obter perfil
- `PUT /api/auth/profile` - Atualizar perfil

### Concursos
- `GET /api/contests` - Listar concursos
- `POST /api/contests` - Criar concurso
- `GET /api/contests/:id` - Obter concurso
- `PUT /api/contests/:id` - Atualizar concurso
- `DELETE /api/contests/:id` - Deletar concurso
- `POST /api/contests/:contestId/topics` - Adicionar tópico
- `DELETE /api/contests/:contestId/topics/:topicId` - Remover tópico

### Editais
- `POST /api/editais/:contestId/upload` - Upload de edital
- `POST /api/editais/:contestId/process` - Processar edital
- `GET /api/editais/:contestId/file` - Download do edital
- `DELETE /api/editais/:contestId` - Deletar edital

### Cards
- `GET /api/cards` - Listar cards
- `POST /api/cards` - Criar card manual
- `GET /api/cards/:id` - Obter card
- `PUT /api/cards/:id` - Atualizar card
- `DELETE /api/cards/:id` - Deletar card
- `POST /api/cards/generate` - Gerar cards por IA

### Estudo
- `GET /api/study/session/:contestId` - Obter sessão de estudo
- `POST /api/study/review` - Revisar card
- `GET /api/study/stats/:contestId` - Estatísticas de estudo
- `POST /api/study/cards` - Adicionar card ao estudo
- `DELETE /api/study/cards/:cardId` - Remover card do estudo

### Tópicos
- `GET /api/topics` - Listar tópicos
- `POST /api/topics` - Criar tópico
- `GET /api/topics/:id` - Obter tópico
- `PUT /api/topics/:id` - Atualizar tópico
- `DELETE /api/topics/:id` - Deletar tópico

### Subtópicos
- `GET /api/subtopics` - Listar subtópicos
- `POST /api/subtopics` - Criar subtópico
- `GET /api/subtopics/:id` - Obter subtópico
- `PUT /api/subtopics/:id` - Atualizar subtópico
- `DELETE /api/subtopics/:id` - Deletar subtópico

## 🔒 Autenticação

Todas as rotas protegidas requerem um token JWT no header:
```
Authorization: Bearer <token>
```

## 📊 Algoritmo de Repetição Espaçada

O sistema utiliza o algoritmo SM-2 (SuperMemo) para otimizar o aprendizado:

- **Qualidade 0-2**: Card volta para aprendizado
- **Qualidade 3-5**: Card avança no cronograma
- **Intervalos**: 1 dia → 6 dias → intervalo × fator de facilidade
- **Fator de facilidade**: Ajustado baseado na performance (1.3 - 2.5+)

## 🎯 Limitações por Assinatura

### Usuários Gratuitos
- 1 geração de cards por subtópico
- Funcionalidades básicas de estudo

### Usuários Premium
- Gerações ilimitadas de cards
- Estatísticas avançadas
- Funcionalidades futuras

## 🚀 Deploy

### Usando Railway/Render
1. Configure as variáveis de ambiente
2. Configure o banco PostgreSQL
3. Execute as migrations: `npm run prisma:migrate`
4. Deploy: `npm start`

### Usando Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3001
CMD ["npm", "start"]
```

## 🧪 Testes

```bash
# Executar testes (quando implementados)
npm test
```

## 📝 Estrutura do Projeto

```
src/
├── controllers/     # Controladores das rotas
├── middleware/      # Middlewares (auth, error, upload)
├── models/          # (Não usado - Prisma gerencia)
├── routes/          # Definições de rotas
├── services/        # Serviços (IA, etc.)
├── types/           # Tipos TypeScript
├── utils/           # Utilitários (auth, prisma, etc.)
└── index.ts         # Arquivo principal

prisma/
├── schema.prisma    # Schema do banco de dados
└── migrations/      # Migrations do banco

uploads/             # Arquivos enviados (editais)
```

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença ISC.

